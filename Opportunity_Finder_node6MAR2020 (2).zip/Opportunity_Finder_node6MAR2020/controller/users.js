const express = require("express");
const application = express();
 const path = require("path");
const mongoose = require("mongoose");

const UserModel = mongoose.model('User');
const ProcessModel = mongoose.model('Process');
const SecondProcessModel =mongoose.model('SecondProcess')
const ClassificationModel = mongoose.model('Classification')
const GoogleCharts= require("google-charts");
const session = require('express-session');
var uniqBy = require('lodash.uniqby');
var BusinessModel = mongoose.model('Business')
application.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));

mongoose.set('useFindAndModify', false);
// import {GoogleCharts} from 'google-charts';

// var dir = path.join(__dirname, './views/images');
application.use('/user', express.static('views/images'));

application.use(express.static(__dirname + '/public'));
// application.use(express.static(dir));
const router=express.Router();
router.get("/", (req, res)=>{
    //res.render("views/adminHome")
});
router.get("/adminHome", (req, res)=>{
res.render("adminHome")
});
router.get("/captureProcess", (req, res)=>{
    res.render("captureProcess")
});



router.get("/processDiscovery", (req, res)=>{
    res.render("processDiscovery")
});
router.get("/businessTable", (req, res)=>{
    res.render("businessTable")
});
router.get("/confirmBusiness", (req, res)=>{
    res.render("confirmBusiness")
});

router.get("/processViewById", (req, res)=>{
   
    ProcessModel.find((err, docs) => {
        if(!err){
        res.render("processViewById", {list: docs});
      
        console.log(docs);
        }
        else {
        console.log('Failed to retrieve the Course List: '+ err);
        }
        });
});
router.get("/businessTableDetails", (req, res)=>{
   
    SecondProcessModel.find((err, docs) => {
        if(!err){
        res.render("businessTable", {list: docs});
      
        console.log(docs);
        }
        else {
        console.log('Failed to retrieve the Course List: '+ err);
        }
        });
});
router.post("/classification",(req,res)=>{
    var classificationmodel = new ClassificationModel();
    classificationmodel.Total_Count=req.body.Total_Count;
    classificationmodel.Simple_Count=req.body.Simple_Count;
    classificationmodel.Medium_Count=req.body.Medium_Count;
    classificationmodel.Complex_Count=req.body.Complex_Count;
    ClassificationModel.find((err,doc)=>{
        if(!err)
        {
        if(doc.length)
        {
            var updated_doc={$set: {Total_Count:req.body.Total_Count,Simple_Count:req.body.Simple_Count,Medium_Count:req.body.Medium_Count,Complex_Count:req.body.Complex_Count}}
            ClassificationModel.updateOne({Total_Count:doc[0].Total_Count},updated_doc,(err,doc)=>{
                if(!err)
                {
                    res.send("Updated sucessfully")
                }
                else{
                    console.log(err);
                    res.send("error Occured in proceeding")
                }
            });
        }
        // { $set: { <field1>: <value1>, ... } }
        else
        {
            classificationmodel.save((err,doc)=>{
                if(!err)
                {
                    // res.send(simplecount,mediumcount,complexcount);
                    res.send("Successfull")
                }
                else{
                    console.log(err)
                    res.send("error in Proceeding");
                }
            });
        
        }
    }
    else{
        console.log(err)
        res.send("error")
    }
    });

});
// router.get("/functioncall",(req,res)=>{
//  if(req.body.checked!="")
//  {
//     GetSelected(req,res);
//  }
//  else
//  {
//     res.send("please select atleast one process");
//  }
// });
// function GetSelected(req,res) {
//     //Create an Array.
//     var selectedProcess = new Array();
// console.log("i am inside getselected function")
//     //Reference the Table.
//     var processes = document.getElementById("processes");

//     //Reference all the CheckBoxes in Table.
//     var chks = processes.getElementsByTagName("INPUT");

//     // Loop and push the checked CheckBox value in Array.
//     for (var i = 0; i < chks.length; i++) {
//         if (chks[i].checked) {
//             selectedProcess.push(chks[i].value);
//         }
//     }

//     //Display the selected CheckBox values.
//     if (selectedProcess.length > 0) {
//         res.redirect("user/addSelectedProcess")
//     }
// };

router.post("/addSelectedProcess",(req,res)=>{
    var businessmodel= new BusinessModel();
    businessmodel.Selected_Process=req.body.Selected_Process;
    businessmodel.Total_Count=businessmodel.Selected_Process.length;
    var simplecount=0;
    var mediumcount=0;
    var complexcount=0;
    
    for(i=0;i<businessmodel.Selected_Process.length;i++){
        if(businessmodel.Selected_Process[i].includes('Simple'))
             simplecount=simplecount+1;
        else if(businessmodel.Selected_Process[i].includes('Medium'))
            mediumcount=mediumcount+1;
        else
            complexcount=complexcount+1;
    }
    businessmodel.Simple_Count=simplecount;
    businessmodel.Medium_Count=mediumcount;
    businessmodel.Complex_Count=complexcount;
    businessmodel.save((err,doc)=>{
        if(!err)
        {
            console.log(doc)
            // res.send(simplecount,mediumcount,complexcount);
            res.render("confirmBusiness",{list:doc})
        }
        else{
            console.log(err)
            res.send("error in storring the selected processes");
        }
    });

});
// function getprocessid(){
//     var cname  = document.getElementById('clientName').value;
//     var subbusunit  = document.getElementById('sub_buss_unit').value;
//     console.log(cname);
//     var query={clientName:cname,Sub_Buss_Unit:subbusunit}
//     ProcessModel.find({query},(err,doc)=>{
//         console.log("i am in getprocessid function")
//         // console.log(doc);
//         if(doc.length!=0){
//             if(!err)
//             {
//                 // res.render("processviewById",{viewtitle:doc[0].Proc_Id});
//                 document.getElementById('procid').value=doc[0].Proc_Id;
//             }
//         }
//         else
//         {
//             res.render("processviewById",{viewtitle:"there is no proccess id with the above values"});
//         }
//     });
// }
router.get("/adminViewById", (req, res)=>{
     res.render("adminViewById")
 });
 router.get("/approveProcess", (req, res)=>{
    ProcessModel.find({Status:"REQUESTED"},(err, docs) => {
        if(!err){
        res.render("approveProcess", {list: docs});
      
        console.log(docs);
        }
        else {
        console.log('Failed to retrieve the Course List: '+ err);
        }
        });
});
router.get("/processPrioritization", (req, res)=>{
    res.render("processPrioritization")
});
 router.get("/userManagement", (req, res)=>{
    res.render("userManagement")
});
router.get("/register", (req, res)=>{
    res.render("register")
});
router.get("/approved", (req, res)=>{
    res.render("approved")
});
router.get("/secondProcess", (req, res)=>{
    res.render("secondProcess")
});
router.get("/About", (req, res)=>{
    res.render("About")
});
router.get("/Contact", (req, res)=>{
    res.render("Contact")
});
router.post("/checkUser",(req,res) => {
    // var sess=req.session;
    if(req.body.userName=="ADMIN"&&req.body.password=="ADMIN$1"){
        res.render("adminHome",{viewtitle:"ADMIN"});
    }
    else{
    UserModel.findOne({
        userName:req.body.userName,
        password: req.body.password
      })
      .exec(function (err, result) {
        if(result) { // auth was successful
          req.session.user = result; // so writing user document to session
          console.log(result.userName);
          return res.render("adminHome",{viewtitle:result.userName}); // redirecting user to interface
        }
  
        // auth not successful, because result is null
        res.render("index",{viewtitle :"Invalid User"}) // redirect to login page
    });
    }
});
router.post("/adduser", (req, res)=>{
    if(req.body.password==req.body.cpassword){
    var usermodel = new UserModel();
    usermodel.userName = req.body.userName;
   usermodel.email = req.body.email;
    usermodel. employeeId = req.body.employeeId;
    usermodel.password = req.body.password;
    usermodel.save((err, doc) => {
        if (!err){
        res.send("Registerd Successfully");
        //console.log("success");
    }
        else{
        console.log('Error during record insertion : ' + err);
        res.send("Error Occured");
    }
});
    }
    else
    res.render("register",{viewtitle:"Password not matched.."});
});

router.post("/addProcess", (req, res)=>{
    try{
    var processmodel = new ProcessModel();
    processmodel.clientName = req.body.clientName;
    processmodel.Buss_Unit = req.body.Buss_Unit;
    processmodel.Sub_Buss_Unit = req.body.Sub_Buss_Unit;
    processmodel.Proc_Name = req.body.Proc_Name;
    processmodel. Proc_Id = req.body.Proc_Id;
    processmodel.Proc_Desc = req.body.Proc_Desc;
    processmodel.Mon_Vol = req.body.Mon_Vol;
    processmodel.AHT = req.body.AHT;
    processmodel.FTE = req.body.FTE;
    processmodel.SLA = req.body.SLA;
    processmodel.TAT = req.body.TAT;
    processmodel.App_Used = req.body.App_Used;
    processmodel.Doc_Present = req.body.Doc_Present;
    processmodel.Rule_Based = req.body.Rule_Based;
    processmodel.Stuc_Data = req.body.Stuc_Data;
    processmodel.Inp_Data_Type = req.body.Inp_Data_Type;
    processmodel.Amenable_RPA = req.body.Amenable_RPA;
    processmodel.Amenable_Cognitive = req.body.Amenable_Cognitive;
    processmodel. Automation_Ready = req.body.Automation_Ready;
    processmodel.AP_Perc = req.body.AP_Perc;
    processmodel.FTE_Benefit = req.body.FTE_Benefit;
    processmodel.Status="REQUESTED";
    processmodel.save((err, doc) => {
        if (err){
            if (err.name === 'MongoError' && err.code === 11000) {
                // Duplicate username
                return res.status(422).send({ success: false, message: 'Process already exist!' });
              }
        // res.redirect("/user/processlist");
        // console.log("success");
        return res.status(422).send(err);
    }
        else{
       res.render("secondProcess",{list:doc});
    }
});
}
catch(e){
    res.status(500).json({
        success: false,
        message: 'Server error. Please try again.',
        error: error.message,
      });
}   
});
router.post("/addProcessTwo", (req, res)=>{
    var secondprocessmodel = new SecondProcessModel();
    secondprocessmodel.Proc_Id = req.body.Proc_Id;
    secondprocessmodel.Num_of_apps = req.body.Num_of_apps;
    secondprocessmodel.Num_of_mainframe = req.body.Num_of_mainframe;
    secondprocessmodel.Num_of_Citrix = req.body.Num_of_Citrix;
    secondprocessmodel.Third_party_sites = req.body.Third_party_sites;
    secondprocessmodel.Num_of_scrs = req.body.Num_of_scrs;
    secondprocessmodel.Num_of_proccessteps = req.body.Num_of_proccessteps;
    secondprocessmodel.Num_of_Scenarios = req.body.Num_of_Scenarios;
    secondprocessmodel.Num_of_Decpoints = req.body.Num_of_Decpoints;
    secondprocessmodel.Num_of_standardinput = req.body.Num_of_standardinput;
    secondprocessmodel.Intr_dynamic_table = req.body.Intr_dynamic_table;
    secondprocessmodel.Num_of_basedcontrols = req.body.Num_of_basedcontrols;
    secondprocessmodel.Num_of_accessprofile = req.body.Num_of_accessprofile;
    secondprocessmodel.Num_of_browsersupp = req.body.Num_of_browsersupp;
    secondprocessmodel.Operation_stability = req.body.Operation_stability;
    secondprocessmodel.Freq_change = req.body.Freq_change;
    secondprocessmodel.Svc_lvl_agr = req.body.Svc_lvl_agr;
    secondprocessmodel.Num_of_getsignoff = req.body.Num_of_getsignoff;
    secondprocessmodel.Num_of_Envsetup = req.body.Num_of_Envsetup;
    secondprocessmodel.Func_point = req.body.Func_point;
    secondprocessmodel.Monthly_effsaving = req.body.Monthly_effsaving;
    secondprocessmodel.Effort = req.body.Effort;
    secondprocessmodel.Quadrant = req.body.Quadrant;
    if(secondprocessmodel.Func_point <= 25)
    secondprocessmodel.Classification = "Simple";
    else if(secondprocessmodel.Func_point > 25 && secondprocessmodel.Func_point <= 50)
    secondprocessmodel.Classification = "Medium";
    else
    secondprocessmodel.Classification = "Complex";
    secondprocessmodel.save((err, doc) => {
        if (err){
            if (err.name === 'MongoError' && err.code === 11000) {
                // Duplicate username
                return res.status(422).send({ success: false, message: 'Process already exist!' });
              }
        // res.redirect("/user/processlist");
        // console.log("success");
        return res.status(422).send(err);
    }
        else{
       res.render("secondProcess",{viewtitle:"Captured Successfully"});
    }

});
});
router.get('/list', (req,res) => {
    ProcessModel.find((err, docs) => {
    if(!err){
    res.render("processPrioritization", {list: docs});
  
    console.log(docs);
    }
    else {
    console.log('Failed to retrieve the Course List: '+ err);
    }
    });
    });
    router.get('/userList', (req,res) => {
        UserModel.find((err, docs) => {
        if(!err){
        res.render("viewUser", {list: docs});
        console.log(docs);
        }
        else {
        console.log('Failed to retrieve the Course List: '+ err);
        }
        });
        });

    router.get('/viewbubblechart', (req,res) => {
        ProcessModel.find((err, docs) => {
            // GoogleCharts.load('current', {'packages':['corechart']});
            // GoogleCharts.setOnLoadCallback(drawChart);
      
            // function drawChart() {
            //     alert("hbjh")
            //   var data = GoogleCharts.api.visualization.arrayToDataTable([
            //     ['Year', 'Sales', 'Expenses'],
            //     ['2004',  1000,      400],
            //     ['2005',  1170,      460],
            //     ['2006',  660,       1120],
            //     ['2007',  1030,      540]
            //   ]);
      
            //   var options = {
            //     title: 'Company Performance',
            //     curveType: 'function',
            //     legend: { position: 'bottom' }
            //   };
      
            //   var chart = new GoogleCharts.api.visualization.LineChart(document.getElementById('curve_chart'));
      
            //   chart.draw(data, options);
            // }
            console.log(docs);
        if(!err){
        res.render("bubblechart" ,{list: docs});
//         var info=[]
// info1=[];
// docs.forEach(element => {
//     console.log(element)
// info[0]=element.AP_Perc
// info[1]=element.FTE_Benefit
// info1.push(info);
// info=[];

// });


        }
        else {
        console.log('Failed to retrieve the Course List: '+ err);
        }
        
        });
        });
         

    router.get('/viewById/:id', (req, res) => {
        console.log("Inside router")
        console.log(req.params.id);
    //    if(req.params.id) {
        ProcessModel.find(req.params.id,(err, doc) => {
            console.log(doc)
            if(doc.length!=0){
        if (doc[0].Status=="APPROVED") {
        res.render("processList", {viewtitle:"process",process:doc[0]
        });
        console.log(doc);
        }
        else
        res.render("processViewById",{viewtitle:"Process is not Approved wait for the admin approval"});
        }
        else{
            res.render("processViewById",{viewtitle : "Process is not captured!" })
        }
    });
    // }
    // else
    // res.render("processViewById",{viewtitle:"Please enter the Process Id"});
        });
router.get("/approveProcessById/:id",(req,res)=>{
    // console.log(req)
  if(req.params.id.match(/^[0-9a-fA-F]{24}$/)){
      console.log(req.params.id.match(/^[0-9a-fA-F]{24}$/))
      ProcessModel.findByIdAndUpdate(req.params.id,{Status:"APPROVED"}, (err,doc)=>{
          console.log(doc)
        if (!err) {
            res.render("approved"); 
           }         
     else
       { res.send('Error during updating the record: ' + err);}

      });
  }
  else{
    res.render("approveProcess",{viewtitle : "Invalid"})  
  }
});

// router.get("/approveProcessById/:id", (req, res)=>{
//     console.log(req.params.id);
//     if(req.params.id){
//         ProcessModel.findById(req.params.id,(err,doc)=>{
//            if(doc.length!=0){
//                 if(doc.Status=="REQUESTED"){
//                     ProcessModel.updateOne({ Status: "APPROVED" }, (err, doc) => {
//                         //console.log(doc)
//                         if (!err) {
//                              res.render("approveProcess",{viewresult:"APPROVED Successfully"}); 
//                             }         
//                       else
//                         { res.send('Error during updating the record: ' + err);}
//                             });
//                 }
//                 else{
//                     res.render("approveProcess",{viewtitle : "Process is alredy approved!"})
//                 }
//            }
//            else{
//             res.render("approveProcess",{viewtitle : "Process is not captured!"})
//            }
//         });
    
//         }
//         else
//         res.render("approveProcess",{viewtitle : "please enter the Process Id"})   
               
//         });
    //Router Controller for DELETE request
router.get('/delete/:id', (req, res) => {
    //var valid = mongoose.Types.ObjectId.isValid(req.params.id);
    if(req.params.id.match(/^[0-9a-fA-F]{24}$/)){
    UserModel.findByIdAndRemove(req.params.Proc_Id, (err, doc) => {
    if (!err) {
    res.redirect('/user/list');
    }
    else { console.log('Failed to Delete Course Details: ' + err); }
    });
}
else
res.send('error: please provide correct id');
    });
    application.get('*', function(req, res){
        res.status(404).send('what???');
      });

 router.get('/:id', (req, res) => {
        ProcessModel.findById(req.params.id, (err, doc) => {
            console.log(doc)
            if(doc.length!=0){
                console.log(doc.Status)
                if (doc.Status=="APPROVED") {
                res.render("processList", {viewtitle:"process",process:doc
                });
                //console.log(doc);
                }
                else
                res.render("processViewById",{viewtitle:"Process is not Approved wait for the admin approval"});
               //res.send("Process Not Approved"); 
            }
                else{
                    res.render("processViewById",{viewtitle : "Process is not captured!" })
                }
        });
        });
module.exports = router;