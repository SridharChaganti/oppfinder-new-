const mongoose = require("mongoose");

var ClassificationSchema = new mongoose.Schema({
     
    
    Total_Count:{
      type : Number,
      required : "Required"
    },
    Simple_Count: {
      type : Number,
      required : "Required"
    },
    Medium_Count: {
      type : Number,
      required : "Required"
    },
    Complex_Count: {
      type : Number,
      required : "Required"
    },
   
},
    {
        toObject: {
          virtuals: true,
        },
        toJSON: {
          virtuals: true,
        },
});

mongoose.model('Classification', ClassificationSchema);
